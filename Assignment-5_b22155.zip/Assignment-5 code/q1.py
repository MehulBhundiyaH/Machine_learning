import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from keras.models import Sequential
from sklearn.model_selection import train_test_split
from keras.layers import Dense, Conv2D, Flatten, MaxPooling2D


# Fuunction for loading the images

def loader(trainp,testp):
    training_list=os.listdir(trainp)
    length_classes=len(training_list)
    x_train=[]
    x_test=[]
    y_train=[]
    y_test=[]

    for label, folder in enumerate(training_list):
        p1=trainp + '/'+ str(folder)
        imgs=os.listdir(p1)
        # print(imgs)


        for f in imgs:
            p2=p1 + '/'+ str(f)
            
            # reading the image from the directory
            img=cv2.imread(p2)

            #appending image to the training data list
            x_train.append(img)
            y_train.append(label)
        #load test data
        p1= testp + '/'+ str(folder)
        imgs=os.listdir(p1)

        for f in imgs:
            p2=p1 + '/'+ str(f)
            img=cv2.imread(p2)
            x_test.append(img)
            y_test.append(label)
    x_train=np.asarray(x_train)
    y_train=np.asarray(y_train)
    x_test=np.asarray(x_test)
    y_test=np.asarray(y_test)

    return x_train,y_train,x_test,y_test


training_path="cifar-3class-data/train"
testing_path="cifar-3class-data/test"
x_train,y_train,x_test,y_test=loader(training_path,testing_path)
print("Size of training data : ",x_train.shape)

figre,axes=plt.subplots(1,4,figsize=(15,5))
for i in range(4):
    ind=np.random.randint(len(x_train))
    axes[i].imshow(x_train[ind])
    axes[i].set_title(f'Class: {y_train[ind]}')
    axes[i].axis('off')
plt.show()


X_train,X_validation,Y_train,Y_validation=train_test_split(x_train,y_train,test_size=0.10)

print("Size of training data(new) : ",X_train.shape)
print("Size of Validation data : ",X_validation.shape)


# vectorising the images 

vec_len=X_train.shape[1]*X_train.shape[2]*X_train.shape[3]
X_train=X_train.reshape(X_train.shape[0],vec_len).astype('float32')
X_validation=X_validation.reshape(X_validation.shape[0],vec_len).astype('float32')


# Normalising the vectors

X_train=X_train/255
X_validation=X_validation/255

# Learning model

mdl=Sequential([Dense(256,activation='relu'),
                Dense(128,activation='relu'),
                Dense(64,activation='relu'),
                Dense(3,activation='softmax')])

mdl.compile(loss='sparse_categorical_crossentropy',optimizer='adam',metrics=['accuracy'])
inf=mdl.fit(X_train,Y_train,validation_data=(X_validation,Y_validation),epochs=500,batch_size=200)


plt.figure(figsize=(8,6))
plt.plot(inf.history['accuracy'],label='Training accuracy',color='black')
plt.plot(inf.history['val_accuracy'],label='Validation accuracy',color='red')
plt.xlabel("Epochs---->")
plt.ylabel("Accuracy---->")
plt.title("Epoch-wise training and validation accuracies of FCNN")
plt.legend()
plt.show()




# part-ii

# for testing data


X_test=x_test.reshape(x_test.shape[0],vec_len).astype('float32')
X_test=X_test/255

#By testing the model --->

evaluation=mdl.evaluate(X_test,y_test)
print('Test loss : ', evaluation[0])
print('Test Accuracy : ', evaluation[1]*100,'%')