import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split


# part-i

file=pd.read_csv('abalone.csv')
x=file.drop("Rings",axis=1)
y=file['Rings']
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42)

train_data = pd.concat([X_train, y_train], axis=1)
train_data.to_csv('abalone_train.csv', index=False)


test_data = pd.concat([X_test, y_test], axis=1)
test_data.to_csv('abalone_test.csv', index=False)



# part-ii


attributes=['Length','Diameter','Height','Whole weight', 'Shucked weight','Viscera weight','Shell weight']


def corr(l1, l2):
    m1 = np.mean(l1)
    m2 = np.mean(l2)
    up = 0
    dn1, dn2 = 0, 0

    for i in range(len(l1)):
        up += (l1[i] - m1) * (l2[i] - m2)
        dn1 += (l1[i] - m1) ** 2
        dn2 += (l2[i] - m2) ** 2

    dn = (dn1 * dn2) ** 0.5

    if dn == 0:
        return 0  # You can return 0 when the denominator is zero, indicating no linear correlation.

    r = up / dn
    return r


corr_list=[]
for i in train_data.columns:
    corr_list.append(round(corr(list(train_data[i]),list(train_data['Rings'])),2))
corr_list=list(corr_list[:len(corr_list)-1])
print(corr_list)

print('\n')

for j in range(len(corr_list)):
    if corr_list[j]>0.6 and corr_list[j]==max(corr_list):
        print("The attribute which is highly correlated to no. of Rings is : ",attributes[j])
        imp_attr=attributes[j]
imp_atttribute=train_data[imp_attr]
imp_att2=test_data[imp_attr]



u,d=0,0
for i in range(len(train_data)):
    u+= (imp_atttribute.iloc[i]-np.mean(imp_atttribute))*(train_data['Rings'].iloc[i]-np.mean(train_data['Rings']))
    d+= (imp_atttribute.iloc[i]-np.mean(imp_atttribute))**2
slope=u/d

intercept= round(np.mean(train_data['Rings'])  - (slope*np.mean(imp_atttribute)),3)
testX=list(test_data['Shell weight'])
testY=list(test_data['Rings'])
predictions=(imp_atttribute*slope) + intercept
predictions_test=(slope*test_data['Shell weight']) + intercept


plt.scatter(train_data['Shell weight'],train_data['Rings'],color='Blue',label='Actual data')
plt.plot(train_data['Shell weight'],predictions,color='red',label='Regression line')
plt.xlabel("Input")
plt.ylabel("Rings")
plt.legend()
plt.show()

def RMSE(yp,yo):
    count=0
    l=len(yp)
    for i in range(l):
        count+=(yp[i]-yo[i])**2
    rmse=(count/l)**0.5
    return rmse

print("RMSE for training data is : ",round(RMSE(list(predictions),list(train_data['Rings'])),3))
print('\n')


plt.scatter(testY,predictions_test,color='Blue')
# plt.scatter(testX,predictions_test,color='red',label='Predicted Rings')
plt.xlabel("Actual Rings",color='green')
plt.ylabel("Predicted Rings",color='green')
plt.title("Actual Rings(x-axis) vs Predicted Rings(y-axis)" , color='red')
# plt.legend()
plt.show()

print("RMSE for test data is : ",round(RMSE(list(predictions_test),list(test_data['Rings'])),3))

print('\n')

# part-iii



imp_att_array = np.array(imp_atttribute)
imp_att_array2=np.array(imp_att2)



# Define the degree of the polynomial and create the polynomial feature matrix Z for the input attribute:

degrees = [2,3,4,5]  # Specify the degree of the polynomial
for degree in degrees:
    Z = np.zeros((len(train_data), degree + 1))
    Z2 = np.zeros((len(test_data), degree + 1))
      # Convert imp_atttribute to a NumPy array

    for i in range(len(train_data)):
            for j in range(degree + 1):
                Z[i][j] = imp_att_array[i] ** j

    for i in range(len(test_data)):
            for j in range(degree + 1):
                Z2[i][j] = imp_att_array2[i] ** j
    # print(Z)

    coefficients = np.dot(np.dot(np.linalg.inv(np.dot(Z.T, Z)), Z.T), train_data['Rings'])
    y_pred_train = np.dot(Z, coefficients)
    coefficients2 = np.dot(np.dot(np.linalg.inv(np.dot(Z2.T, Z2)), Z2.T), test_data['Rings'])
    y_pred_test = np.dot(Z2, coefficients2)
    rmse_train = RMSE(list(train_data['Rings']), list(y_pred_train))
    rmse_test = RMSE(list(test_data['Rings']), list(y_pred_test))
    print(f'RMSE on the training data for degree {degree} is : {rmse_train:.2f}')
    print(f'RMSE on the testing data for degree {degree} is : {rmse_test:.2f}')


plt.bar(degrees, rmse_train, color='skyblue')
plt.xlabel('Degree of Polynomial')
plt.ylabel('RMSE')
plt.title('RMSE vs Degree of Polynomial')
plt.xticks(degrees)
plt.show()


plt.bar(degrees, rmse_test, color='red')
plt.xlabel('Degree of Polynomial')
plt.ylabel('RMSE')
plt.title('RMSE vs Degree of Polynomial')
plt.xticks(degrees)
plt.show()

xl=list(train_data[imp_attr])
yl=list(train_data['Rings'])
y_pp=list(y_pred_train)


# Combine the x and y labels into tuples using zip
combined = list(zip(xl, y_pp))

# Sort the combined list based on x labels
sorted_combined = sorted(combined, key=lambda x: x[0])

# Extract the sorted x and y labels back into separate lists
sorted_x_labels, sorted_y_labels = zip(*sorted_combined)

plt.scatter(xl,yl,color='blue',label='Best fit curve')
plt.plot(sorted_x_labels,sorted_y_labels,color='red')
plt.xlabel(" Shell weight")
plt.ylabel("Rings")
plt.title("Best fit curve for 5 degree polynomial ")
plt.show()

# print(sorted_x_labels)  # Sorted x labels
# print(sorted_y_labels)

    





