import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from scipy.stats import norm
from sklearn.metrics import confusion_matrix


ftrain,ftest=pd.read_csv("iris_train.csv"),pd.read_csv("iris_test.csv")
file_train=pd.read_csv("iris_train.csv" , usecols=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm'])
# print(file_train)
file_test=pd.read_csv("iris_test.csv" , usecols=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm'])
y_label_train=list(ftrain['Species'])
y_label_test=list(ftest['Species'])

mean_val_train,mean_val_test=file_train.mean(axis=0),file_test.mean(axis=0)
f1,f2=(file_train-mean_val_train),(file_test-mean_val_test)
f1T,f2T=f1.T,f2.T
corr1,corr2=np.dot(f1T,f1),np.dot(f2T,f2)
e_val1,e_vector1=np.linalg.eig(corr1)
e_val2,e_vector2=np.linalg.eig(corr2)

evreduced1=np.zeros((4,1))
for i in range(4):
    for j in range(1):
        evreduced1[i][j]=e_vector1[i][j]
q=(evreduced1.T)
reduced_data1=np.dot(file_train,evreduced1)
# print(reduced_data1)

evreduced2=np.zeros((4,1))
for i in range(4):
    for j in range(1):
        evreduced2[i][j]=e_vector2[i][j]
q=(evreduced2.T)
reduced_data2=np.dot(file_test,evreduced2)
# print(reduced_data2)


# part-2


x1,x2=[],[]
for i in range(len(reduced_data1)):
    x1.append(reduced_data1[i])
for i in range(len(reduced_data2)):
    x2.append(reduced_data2[i])



def bayesClassifier(dataRed,target,x):
    classes=np.unique(target)
    prob=[]

    for c in classes:
        dataClass=[dataRed[i] for i in range(len(dataRed)) if target[i]==c]
        meann=np.mean(dataClass)
        stdd=np.std(dataClass)

        pro=norm.pdf(x,loc=meann,scale=stdd)
        prob.append(pro)
    predictedClass=classes[np.argmax(prob)]
    return predictedClass

y_predicted=[bayesClassifier(x1,y_label_train,x) for x in x2 ]
# print(y_predicted,y_label_test)
def accu(yp,yo):
    count=0
    for i in range(len(yo)):
        if yp[i]==yo[i]:
            count+=1
        else:
            continue
    return (count/len(yo))*100

print("The accuracy of this classifier is : ",accu(y_predicted,y_label_test))
print('\n')

    
confusion_mat=confusion_matrix(y_label_test,y_predicted)
print(" Confusion matrix : ")
print(confusion_mat)

class_names=['class 1','class 2','class 3']
plt.figure(figsize=(8, 6))
sns.set(font_scale=1.2)  # Adjust font size 
sns.heatmap(confusion_mat, annot=True , fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()
