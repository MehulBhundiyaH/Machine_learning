import pandas as pd
import numpy as np
from scipy.stats import multivariate_normal
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix


# Load the train and test datasets
ftrain, ftest = pd.read_csv("iris_train.csv", usecols=['SepalLengthCm', 'SepalWidthCm', 'PetalLengthCm', 'PetalWidthCm', 'Species']), pd.read_csv("iris_test.csv", usecols=['SepalLengthCm', 'SepalWidthCm', 'PetalLengthCm', 'PetalWidthCm', 'Species'])

# Extract the class labels
y_train = ftrain['Species']
y_test = ftest['Species']
# print(y_test)

# Remove the 'Class' column to get the feature data
X_train = ftrain.drop('Species', axis=1).values
X_test = ftest.drop('Species', axis=1).values
# print(X_test)

# Define the number of classes and features
classes=np.unique(y_train)
num_classes = len(np.unique(y_train))
num_features = 4

# Initialize arrays to store the likelihood of each test sample for each class
likelihoods = np.zeros((len(X_test), num_classes))

# Initialize the prior probabilities for each class
prior_probs = np.zeros(num_classes)


# Calculate the prior probabilities
for i in range(num_classes):
    prior_probs[i] = np.sum(y_train == classes[i]) / len(y_train)

# Initialize arrays to store class means and covariances
class_means = []
class_covariances = []

# Estimate the parameters for each class
for i in range(num_classes):
    class_data = X_train[y_train == classes[i]]
    if len(class_data) > 0:
        class_means.append(np.mean(class_data, axis=0))
        class_covariances.append(np.cov(class_data, rowvar=False))
    else:
        # If the class has no data, use a small identity matrix for covariance to avoid errors
        class_means.append(np.zeros(num_features))
        class_covariances.append(np.identity(num_features))

# print(class_covariances)

# Calculate the likelihood of each test sample for each class
for i in range(num_classes):
    likelihoods[:, i] = multivariate_normal.pdf(X_test, mean=class_means[i], cov=class_covariances[i])
# print(likelihoods)
# Calculate the posterior probabilities 
posteriors = likelihoods * prior_probs

# print(posteriors)

# Make predictions based on the class with the highest posterior probability
predicted_classes_indices =  np.argmax(posteriors, axis=1)
predicted_classes=[classes[i] for i in predicted_classes_indices]
# print(predicted_classes)

def accu(yp,yo):
    count=0
    for i in range(len(yo)):
        if yp[i]==yo[i]:
            count+=1
        else:
            continue
    return (count/len(yo))*100

print("The accuracy of this classifier is : ",accu(predicted_classes,y_test))
print('\n')

confusion_mat=confusion_matrix(y_test,predicted_classes)
print(" Confusion matrix : ")
print(confusion_mat)

class_names=['class 1','class 2','class 3']
plt.figure(figsize=(8, 6))
sns.set(font_scale=1.2)  # Adjust font size 
sns.heatmap(confusion_mat, annot=True , fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()



#part-iii

print("The difference between the two accuracies is zero as they both are same")