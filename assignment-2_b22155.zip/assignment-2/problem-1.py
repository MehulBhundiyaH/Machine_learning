import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sklearn
from sklearn.model_selection import train_test_split
from collections import Counter
from sklearn.metrics import confusion_matrix
import seaborn as sns


# part- a 


file=pd.read_csv("Iris.csv")
f1=pd.read_csv('Iris.csv',usecols=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm'])
# print(f1)
arr=(file['Species']).tolist
# print(arr)

# part-b


for i in f1:
    q1=np.percentile(f1[i],25)
    q2=np.percentile(f1[i],50)
    q3=np.percentile(f1[i],75)
    # print(q1,q2,q3)
    iqr=q3-q1
    y=(q3+(1.5*iqr))
    z=(q1-(1.5*iqr))
    for index,j in enumerate(f1[i]):
        if (j>y) or (j<z):
            # print(j)
            f1.at[index,i]=q2
        else:
            continue
f1.to_csv("X .csv",index=False)


#part-c
mean_values = f1.mean(axis=0)
X=f1-mean_values
X_trans=X.T
corr_mat=np.dot(X_trans,X)
# print(corr_mat)

e_val,e_vector=np.linalg.eig(corr_mat)
# print(e_val)
# print(e_vector)
evreduced=np.zeros((4,2))
for i in range(4):
    for j in range(2):
        evreduced[i][j]=e_vector[i][j]
q=(evreduced.T)
# print(evr)

reduced_data=np.dot(f1,evreduced)
xx=reduced_data[:,0]
mxx=np.mean(xx)
# print(xx)
yy=reduced_data[:,1]
myy=np.mean(yy)
# plt.scatter(xx,yy,c="blue")

# plt.title("Scatter plot of reduced data")
# # plt.grid(True)
# plt.show()
plt.scatter(xx, yy, c="blue")

# Plot the eigen vectors as arrows
origin = np.zeros(2)
for i in range(2):
    plt.quiver(mxx,myy, evreduced[0, i], evreduced[1, i], angles='xy', scale_units='xy', scale=0.7, color='red', label=f'Eigen Vector {i+1}')

plt.title("Scatter plot of reduced data with Eigen Vectors")
plt.legend()
plt.grid(True)
plt.show()


rec_data=np.dot(reduced_data,q)

sqdiff=(f1-rec_data)**2
msd=np.mean(sqdiff,axis=0)
rmse=np.sqrt(msd)
print("RMSE is : ",rmse)

x_label=reduced_data
y_label=list(file['Species'])
# print(y_label)

x_train,x_test,y_train,y_test=train_test_split(x_label,y_label,random_state=104,test_size=0.20,shuffle=True)
# print(len(y_test))
actual_predicted=[]
for i in range(len(x_test)):
               l=[]
               for j in range(len(x_train)):
                    ed=0
                    ed=(x_test[i][0]-x_train[j][0])**2 +(x_test[i][1]-x_train[j][1])**2
                    ed=ed**0.5
                    l.append([ed,y_train[j]])
               l.sort()
               k_neighbor=l[:5]
            #    print(k_neighbor)
               predicted_class=Counter(k_nb[1] for k_nb in k_neighbor ).most_common(1)[0][0]
               actual_predicted.append([y_test[i],predicted_class])
ap_mat=np.array(actual_predicted)
actuall=[item[0] for item in actual_predicted]
predictedd=[item[1] for item in actual_predicted]
# print(ap_mat)
# confusion_mat=confusion_matrix((),(item[1] for item in actual_predicted))
confusion_mat=confusion_matrix(actuall,predictedd)
print(" Confusion matrix : ")
print(confusion_mat)

class_names=['class 1','class 2','class 3']
plt.figure(figsize=(8, 6))
sns.set(font_scale=1.2)  # Adjust font size 
sns.heatmap(confusion_mat, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()



                


